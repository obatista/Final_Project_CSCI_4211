package com.example.stepup;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


import java.math.BigDecimal;


public class Breathing extends  AppCompatActivity implements SensorEventListener , OnClickListener {

    private SensorManager mSensorManager;
    private Sensor gyroscope ;

    private Button startButton ;
    private Button stopButton ;

    private boolean mInitialized = false;

    public float timestamp;
    private float breathsPerMinute;

    private float onebreath;
    private float secondsMinute;
    private float billion;

    private float low;
    private float high;

    @Override

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breathing);

        mInitialized = false;
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        startButton =  (Button) findViewById(R.id.button2);
        stopButton =  (Button) findViewById(R.id.button4);

        startButton.setOnClickListener(this);
        stopButton.setOnClickListener(this);

        startButton.setEnabled(true);
        stopButton.setEnabled(false);


        onebreath = (float)1.0;
        secondsMinute = (float)60.0;
        billion = (float)1e-9;
        low = (float)10;
        high = (float)40;
    }


    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (mInitialized == true) {
            mSensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    @Override
    public void onSensorChanged(SensorEvent event) {

        if (mInitialized) {

            float x  = event.values[0] ;

          //  Log.d("Y", "Y: " + Float.toString(x) + "  " + Float.toString(timestamp) );

            if (x > 0.1 )
            {
                float deltaT = Math.abs(timestamp - event.timestamp);
                float deltaTsec = deltaT * billion;
                breathsPerMinute = (onebreath / deltaTsec) * secondsMinute;

                timestamp = event.timestamp;
            }

            if ( (breathsPerMinute > low) && (breathsPerMinute < high) ) {
                BigDecimal bd = new BigDecimal(Float.toString(breathsPerMinute));
                bd = bd.setScale(1, BigDecimal.ROUND_HALF_UP);
                breathsPerMinute = bd.floatValue();
                 TextView text = (TextView)findViewById(R.id.textView5);
                 text.setText( breathsPerMinute + " bpm");
            }

        }

    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()){
            case R.id.button2:

                startButton.setEnabled(false);
                stopButton.setEnabled(true);
                mInitialized = true;

                gyroscope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
                mSensorManager.registerListener(this, gyroscope, 50000);


                break;
            case R.id.button4:
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                mInitialized = false;

                mSensorManager.unregisterListener(this);

                break;

            default:
                break;
        }

    }


    public void selectActivity(View view) {

        Intent intent = new Intent(this, OptionsActivity.class);

        startActivity(intent);

    }

    public void infoButton(View view){

        AlertDialog alertDialog = new AlertDialog.Builder(Breathing.this).create();
        alertDialog.setTitle("Instructions:");
        alertDialog.setMessage("Hold phone at its default orientation either on left side or right side of chest. Press 'START' to begin and 'STOP' to end. Start breathing and wait 3-8 seconds for results. Remove obtrusive clothing for accurate results.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();

    }


}







