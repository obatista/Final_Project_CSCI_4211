package com.example.stepup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity  {

    public boolean userAuthorized;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userAuthorized = false;
    }


    public void openLogin(View view) {

       if (userAuthorized) {
           Intent intent = new Intent(this, OptionsActivity.class);
           startActivity(intent);
       }


        if (userAuthorized == false) {

            Intent intent = new Intent(this, SignUpActivity.class);
            startActivity(intent);
            Toast.makeText(getApplicationContext(), "Please Sign Up!", Toast.LENGTH_LONG).show();
        }




    }

    public void clickSubmit(View view) {


        EditText firstName = (EditText) findViewById(R.id.editText9);
        String fnameIntent = firstName.getText().toString();

        EditText password = (EditText) findViewById(R.id.editText3);
        String passwordIntent = password.getText().toString();

        RequestQueue queue = Volley.newRequestQueue(this);
        Map<String, String> jsonParams = new HashMap<String, String>();

        jsonParams.put("first", fnameIntent);
        jsonParams.put("password", passwordIntent);


        JsonObjectRequest postRequest = new JsonObjectRequest( Request.Method.POST, "http://35.163.205.87:80/queryuser",

                new JSONObject(jsonParams),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {


                            String responseReturn = response.getString("Success");

                            if ( responseReturn.equals("User Exist") ){
                                userAuthorized = true;

                                Toast toast = Toast.makeText(getApplicationContext(), responseReturn, Toast.LENGTH_SHORT);
                                toast.setGravity(Gravity.NO_GRAVITY, 10, 130);
                                toast.show();
                                Toast toast2 = Toast.makeText(getApplicationContext(), "Please Login Below...", Toast.LENGTH_LONG);
                                toast2.setGravity(Gravity.NO_GRAVITY, 10, 130);
                                toast2.show();

                            }

                            if ( responseReturn.equals("User Not Registered!") ){

                                Toast toast = Toast.makeText(getApplicationContext(), responseReturn, Toast.LENGTH_SHORT);
                                toast.setGravity(Gravity.NO_GRAVITY, 10, 130);
                                toast.show();
                                Toast toast2 = Toast.makeText(getApplicationContext(), "Click 'LOGIN' to register...", Toast.LENGTH_LONG);
                                toast2.setGravity(Gravity.NO_GRAVITY, 10, 130);
                                toast2.show();
                                userAuthorized = false;
                            }

                        }catch (JSONException e){

                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //   Handle Error
                        Toast.makeText(getApplicationContext(), "ALERT: Server NOT connected", Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                headers.put("User-agent", System.getProperty("http.agent"));
                return headers;
            }

        };
        queue.add(postRequest);



    }



}
