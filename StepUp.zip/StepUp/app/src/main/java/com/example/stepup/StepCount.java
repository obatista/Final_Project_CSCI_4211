package com.example.stepup;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class StepCount extends  AppCompatActivity implements SensorEventListener , OnClickListener {


    private SensorManager mSensorManager;
    private Sensor mAccelerometer ;

    private Button startButton ;
    private Button stopButton ;

    int stepCounter;
    private boolean mInitialized = false;


    @Override

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step_count);

        mInitialized = false;
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        startButton =  (Button) findViewById(R.id.button7);
        stopButton =  (Button) findViewById(R.id.button8);

        startButton.setOnClickListener(this);
        stopButton.setOnClickListener(this);

        startButton.setEnabled(true);
        stopButton.setEnabled(false);

    }


    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (mInitialized == true) {
            mSensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    @Override
    public void onSensorChanged(SensorEvent event) {


        if (mInitialized) {

            float x = event.values[0] ;
            float y  = event.values[1];
            float z  = event.values[2] ;

            float magnitude = (float) Math.sqrt( (x * x)+(y * y) +(z * z));

        Log.d("Mag", "Magnitude: " + Float.toString(magnitude));

        if (magnitude > 3.5 )
        {
            stepCounter = stepCounter + 1;

        }

            Log.d("Step Counter", "Step Counter : " + Integer.toString(stepCounter));

            TextView text = (TextView)findViewById(R.id.textView4);
            text.setText("" + stepCounter);

        }

    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()){
            case R.id.button7:

                startButton.setEnabled(false);
                stopButton.setEnabled(true);
                mInitialized = true;

                mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
                mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);

                break;
            case R.id.button8:
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                mInitialized = false;

                mSensorManager.unregisterListener(this);

                break;

            default:
                break;
        }

    }


    public void selectActivity(View view) {

        Intent intent = new Intent(this, OptionsActivity.class);

        startActivity(intent);

    }

    public void infoButton(View view){

        AlertDialog alertDialog = new AlertDialog.Builder(StepCount.this).create();
        alertDialog.setTitle("Instructions:");
        alertDialog.setMessage("Hold phone in hand or preferably place in pocket. Press 'START' to begin and 'STOP' to end.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();

    }


}







