package com.example.stepup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

//Web App Import for POST GET PUTS....
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;


import java.util.*;

public class SignUpActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_sign_up);

        Toast.makeText(getApplicationContext(), "Click 'REGISTER' when done.", Toast.LENGTH_LONG).show();


    }


    public void clickRegister(final View view) {


            EditText firstName = (EditText) findViewById(R.id.editText4);
            String fnameIntent = firstName.getText().toString();

            EditText lastName = (EditText) findViewById(R.id.editText5);
            String lnameIntent = lastName.getText().toString();

            EditText age = (EditText) findViewById(R.id.editText6);
            String ageIntent = age.getText().toString();

            EditText weight = (EditText) findViewById(R.id.editText7);
            String weightIntent = weight.getText().toString();

            EditText password = (EditText) findViewById(R.id.editText9);
            String passwordIntent = password.getText().toString();

        if (  ( !firstName.getText().toString().equals("")) && ( !lastName.getText().toString().equals("")) && ( !age.getText().toString().equals("") ) && ( !weight.getText().toString().equals("") ) && ( !password.getText().toString().equals("") ) ) {

            RequestQueue queue = Volley.newRequestQueue(this);
            Map<String, String> jsonParams = new HashMap<String, String>();

            jsonParams.put("first", fnameIntent);
            jsonParams.put("last", lnameIntent);
            jsonParams.put("age", ageIntent);
            jsonParams.put("weight", weightIntent);
            jsonParams.put("password", passwordIntent);
            jsonParams.put("totalSteps", "0");
            jsonParams.put("breathingRate", "0");


            JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, "http://35.163.205.87:80/adduser",

                    new JSONObject(jsonParams),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                Toast.makeText(getApplicationContext(), response.getString("Success"), Toast.LENGTH_LONG).show();

                            } catch (JSONException e) {

                                Toast.makeText(getApplicationContext(), "ALERT: Bad data", Toast.LENGTH_LONG).show();
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //   Handle Error
                            Toast.makeText(getApplicationContext(), "ALERT: Server NOT connected", Toast.LENGTH_LONG).show();
                            Toast.makeText(getApplicationContext(), "ALERT: Failed to register user", Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    headers.put("User-agent", System.getProperty("http.agent"));
                    return headers;
                }

            };
            queue.add(postRequest);


            Intent intent = new Intent(this, OptionsActivity.class);
            startActivity(intent);



        }
        else{
            Toast.makeText(getApplicationContext(), "ALERT: You must fill in ALL fields.", Toast.LENGTH_LONG).show();

        }





}//End of Click Register






}
