package com.example.stepup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class OptionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
    }

    public void breathingRate(View view) {

        Intent intent = new Intent(this, Breathing.class);

        startActivity(intent);

    }


    public void stepCount(View view) {

        Intent intent = new Intent(this, StepCount.class);

        startActivity(intent);

    }

    public void logOut(View view) {

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }



}
