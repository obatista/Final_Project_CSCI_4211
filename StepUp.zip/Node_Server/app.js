var express = require('express');
var fs = require('fs');
var app = express();
var bodyParser = require ('body-parser');
var jsonfile = require ('jsonfile');

app.use (bodyParser.json())

app.get('/', function (req, res) {
  res.send('Welcome to Oliver\'s Health App!');
})

app.get('/querydatabase', function (req, res) {
        var file = '/root/healthApp/users.json';
        var updatedUsers ;
        updatedUsers = jsonfile.readFileSync(file) ;

         res.send(updatedUsers);
})

app.post('/queryuser', function (req, res){

var fn = req.body.first;
var pw = req.body.password;
var file = '/root/healthApp/users.json';
var database = jsonfile.readFileSync(file);
var Authorized = false;
var numberOfUsers = Object.keys(database.Users).length;

console.log('User Queried: ' + fn);
console.log('password: ' + pw);


for (var i = 0; i < numberOfUsers; ++i){
        if(database.Users[i].first == fn  && database.Users[i].password == pw ){
        Authorized = true;

        }

}

if (Authorized){
        res.send('{"Success":"User Exist"}');
        console.log(Authorized);
        console.log('');
        }

if (Authorized == false){
        res.send('{"Success":"User Not Registered!"}');
        console.log(Authorized);
        console.log('');
        }


})


app.post('/adduser', function (req, res) {

        var file = '/root/healthApp/users.json';
        var newUser = req.body;
        var updatedUsers ;

        updatedUsers = jsonfile.readFileSync(file) ;

        updatedUsers["Users"].push(newUser);
        console.log('Updated Database: ')
        console.log('')
        console.log(updatedUsers);

        jsonfile.writeFileSync(file, updatedUsers,{spaces:3});

        res.send('{"Success":"User Registered to Server"}');

})


app.listen(80, function () {
  console.log('Health app listening on port 80!')
})


